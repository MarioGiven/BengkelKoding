import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class Splashpage extends StatelessWidget {
  const Splashpage({super.key});

  @override
  Widget build(BuildContext context) {
    return SplashFull();
  }
}

class SplashFull extends StatefulWidget {
  const SplashFull({super.key});

  @override
  State<StatefulWidget> createState() {
    return _Splashfull();
  }
}

class _Splashfull extends State<SplashFull> {
  @override
  void initState() {
    super.initState();

    Future.delayed(Duration.zero, () {
      Navigator.pushReplacementNamed(context, '/register');
    });
  }

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
        home: Scaffold(
      body: Center(
        child: Text('Hello World!'),
      ),
    ));
  }
}
